# Metric Threshold Flags

**Generated**: 2026-01-03 20:18:34

## Summary

- **Red Flags**: 1
- **Yellow Flags**: 1

## Flags

### Critical (Red)

- 🔴 LTV:CAC below 2.0 - Unit economics challenged (current: 0.00)

### Warning (Yellow)

- 🟡 NRR below 110% - Limited expansion revenue (current: 102.00)


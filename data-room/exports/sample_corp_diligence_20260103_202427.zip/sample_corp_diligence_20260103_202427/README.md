# Sample Corp - Due Diligence Package

**Generated**: 2026-01-03 20:24:27
**Prepared by**: Crowley Capital

---

## Package Contents

### Analysis

- `.gitkeep`
- `cohorts.xlsx`
- `flags.md`
- `metrics.json`
- `parsed_captable.json`
- `series_a_model.json`
- `waterfall.xlsx`

### Reports

- `.gitkeep`
- `investment-memo.md`
- `metrics-dashboard.html`
- `risk-scorecard.md`

### Source Data

- `.gitkeep`
- `.gitkeep`
- `.gitkeep`

---

## File Descriptions

### Analysis Files
| File | Description |
|------|-------------|
| `metrics.json` | Calculated SaaS metrics (ARR, growth, retention) |
| `cohorts.xlsx` | Customer retention cohort analysis |
| `parsed_captable.json` | Parsed cap table structure |
| `round_model.json` | Investment round modeling |
| `waterfall.xlsx` | Exit waterfall scenarios |
| `flags.md` | Metric threshold violations |

### Report Files
| File | Description |
|------|-------------|
| `risk-scorecard.md` | 11-risks framework assessment |
| `investment-memo.md` | Partner meeting memo |
| `metrics-dashboard.html` | Interactive metrics dashboard |

---

## How to Use This Package

1. **Quick Overview**: Start with `investment-memo.md` for executive summary
2. **Risk Analysis**: Review `risk-scorecard.md` for detailed risk assessment
3. **Interactive View**: Open `metrics-dashboard.html` in a browser
4. **Deep Dive**: Examine individual analysis files for detailed data

---

## Contact

Crowley Capital
Austin, TX

---

*This package was generated automatically by the Crowley Capital Diligence Tool*
